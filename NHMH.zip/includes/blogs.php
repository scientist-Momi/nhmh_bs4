<?php

$sql = mysqli_query($conn, "select * from nhmh_blogposts_db order by post_id desc");