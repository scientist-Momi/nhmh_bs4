<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NHMH || Homepage</title>
    <link rel="stylesheet" href="sass/app.css">
    <link rel="icon" href="images/newLogo3.png" type="image/png">
    <script src="javascript/loginScript.js" defer></script>

</head>