<?php

$user_id = stripslashes($_SESSION['staff_uid']);

$msql = mysqli_query($conn, "select * from nhmh_staff_db where unique_id = '$user_id'");
if (mysqli_num_rows($sql) > 0) {
    // $staff_info = mysqli_fetch_assoc($sql);

    $msql10 = mysqli_query($conn, "select * from nhmh_staff_db where not unique_id = '$user_id' order by Staff_id");
}